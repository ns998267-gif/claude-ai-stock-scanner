# Claude AI Stock Market Scanner (Starter ZIP)

यह एक शुरुआती cloud-deployable NSE stock research dashboard है। इसमें:
- 20-bar high breakout screening
- Relative volume और EMA 9/20 trend
- RSI(14) momentum filter
- Google News RSS headlines
- वैकल्पिक Claude AI headline analysis
- वैकल्पिक Telegram alert
- CSV export

## जरूरी सीमाएँ
1. यह ZIP एक working starter है, कोई guaranteed-profit system नहीं।
2. Yahoo Finance (`yfinance`) unofficial data source है। 5-minute data में delay, missing bars या rate limits हो सकते हैं। इसे exchange-grade real-time feed न मानें।
3. डिफॉल्ट watchlist केवल 15 बड़े NSE symbols की है। `data/watchlist.txt` में NSE symbols जोड़कर universe बढ़ाएँ। BSE symbols के लिए अलग data-provider mapping की जरूरत हो सकती है।
4. News RSS में headlines आती हैं; हर खबर का stock से संबंध AI द्वारा संभावित रूप से निकाला जाएगा, इसकी पुष्टि स्वयं करें।
5. Claude API और Telegram optional हैं; इनके लिए अलग API credentials और संभावित शुल्क लग सकते हैं।
6. Signals केवल screening संकेत हैं, buy/sell सलाह नहीं। Live trade से पहले price, liquidity, corporate actions और खबर verify करें।

## अपने कंप्यूटर पर चलाएँ
Python 3.11+ इंस्टॉल करें, ZIP extract करें और project folder में:

```bash
pip install -r requirements.txt
streamlit run app.py
```

फिर browser में `http://localhost:8501` खोलें।

## Claude AI जोड़ें
`.env.example` को `.env` नाम से कॉपी करें और `ANTHROPIC_API_KEY` भरें। फिर environment variables को अपने hosting platform में भी add करें।
स्थानीय run में variables लोड करने के लिए अपने shell में export करें या `python-dotenv` जोड़ें। Cloud hosting में platform के Environment Variables/Secrets सेक्शन का उपयोग करें।

## Telegram जोड़ें
Telegram में BotFather से bot बनाकर token लें, bot को message भेजें और अपने chat ID को `TELEGRAM_CHAT_ID` में रखें। Token किसी के साथ साझा न करें।

## Cloud deployment (Render उदाहरण)
1. ZIP extract करके GitHub repository में files upload करें।
2. Render में **New > Blueprint** चुनकर repository connect करें; `render.yaml` deploy configuration देगा।
3. Deploy के बाद Render के Environment सेक्शन में `ANTHROPIC_API_KEY`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` जोड़ें (जो सुविधाएँ चाहिए केवल वही)।
4. Deploy URL खोलें। Dashboard पर **Run scan** दबाकर scan चलाएँ।

Dockerfile उपलब्ध है, इसलिए इसे अन्य Docker-compatible cloud services पर भी deploy किया जा सकता है। Cloud provider का खर्च और secret configuration अलग होंगे।

## Scanner logic
- Breakout: मौजूदा close, पिछले 20 bars के high से ऊपर।
- Relative volume: मौजूदा volume / पिछले 20 bars के औसत volume।
- Trend: EMA 9 > EMA 20।
- Momentum: RSI 50 से 80 के बीच।
- Daily mode में bar = trading day; 5m mode में bar = 5-minute candle।

## अगला विकास चरण
- Licensed NSE/BSE real-time market-data API integration
- Scheduled scans और persistent database
- Earnings/calendar and corporate-action filters
- Per-symbol news/entity matching
- Backtesting, slippage, brokerage and risk controls
- User authentication and private dashboard
