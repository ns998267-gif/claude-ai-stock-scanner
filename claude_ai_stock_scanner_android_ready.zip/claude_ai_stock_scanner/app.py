import streamlit as st
import pandas as pd
from app.scanner import scan_universe
from app.news import fetch_news
from app.ai import summarize_with_claude
from app.alerts import send_telegram
from app.config import load_symbols

st.set_page_config(page_title="AI Stock Scanner", page_icon="📈", layout="wide")
st.title("📈 AI Stock Market Scanner")
st.caption("NSE watchlist • Breakouts • Volume • Momentum • News • Optional Claude AI")

with st.sidebar:
    st.header("Scanner Settings")
    interval = st.selectbox("Scan timeframe", ["1d", "5m"], index=0,
                            help="Daily data or 5-minute intraday data. Intraday availability may be delayed/limited.")
    min_volume_ratio = st.slider("Minimum relative volume", 1.0, 5.0, 1.5, 0.1)
    symbols = load_symbols()
    st.write(f"Watchlist: {len(symbols)} symbols")
    run = st.button("🔍 Run scan", type="primary", use_container_width=True)
    news_run = st.button("📰 Fetch market news", use_container_width=True)

if "scan_results" not in st.session_state:
    st.session_state.scan_results = None
if "news_results" not in st.session_state:
    st.session_state.news_results = None

if run:
    with st.spinner("Downloading market data and checking signals..."):
        st.session_state.scan_results = scan_universe(symbols, interval, min_volume_ratio)

if news_run:
    with st.spinner("Fetching headlines..."):
        st.session_state.news_results = fetch_news()

results = st.session_state.scan_results
if results is not None:
    st.subheader("Scanner results")
    if results.empty:
        st.info("No matching setups found. Try a lower relative-volume threshold or check data availability.")
    else:
        st.metric("Matching symbols", len(results))
        st.dataframe(results, use_container_width=True, hide_index=True)
        csv = results.to_csv(index=False).encode("utf-8")
        st.download_button("Download scan as CSV", csv, "stock_scan.csv", "text/csv")
        if st.button("Send top results to Telegram"):
            sent = send_telegram(results.head(10).to_string(index=False))
            st.success("Telegram message sent." if sent else "Telegram not configured or send failed.")

news = st.session_state.news_results
if news is not None:
    st.subheader("Market news headlines")
    if news.empty:
        st.info("No headlines returned. RSS availability can vary.")
    else:
        for _, row in news.iterrows():
            st.markdown(f"**{row['title']}**  \n{row['source']} · {row['published']}  \n[Open article]({row['link']})")
        if st.button("Ask Claude to summarize these headlines"):
            with st.spinner("Claude is analyzing the headlines..."):
                summary = summarize_with_claude(news.to_dict("records"))
            st.markdown("### Claude's news summary")
            st.write(summary)

st.divider()
st.caption("Educational research tool only. Signals are rule-based screening results, not buy/sell recommendations. Verify prices, liquidity, corporate actions and news independently.")
